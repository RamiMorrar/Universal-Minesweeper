Hello. I recently made a simple application game using the wxWidgets framework and C++. It's quite a simple game to 
play and it was a nice test using wxWidgets. 
With some simple button events, if-else statements, and for loops, there is MineSweeper. 
Although it is very simple graphically, the great thing about this application is that it's universal on all 
desktop platforms(Windows/Linux/Mac) thanks to wxWidgets' multisystem/OS handling and threading, making it easy to speed up development processes. 
Anyways, I hope you enjoy playing this as much as I did making it. It's quite addicting actually.